$text = Get-Content -Path "~/.qlik/contexts.yml"
$regex = '(?ms)current-context:(.+?)contexts:'
$text = $text -join "`n"
$OutputText = [regex]::Matches($text, $regex) |
              foreach {$_.Groups[1].Value -split $regex}
$OutputText = $OutputText.Replace("`$ref:", "")
$OutputText = $OutputText.Replace(":", "=")
$OutputText = $OutputText.Replace("=`n", "=")
$OutputText = $OutputText.Replace("`"", "")
$AppProps = ConvertFrom-StringData ($OutputText)
$AppProps.GetEnumerator() | ForEach-Object {$_.Value}
[string[]]$l_array = $AppProps.Values | Out-String -Stream